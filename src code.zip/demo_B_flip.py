"""Demo B - one parent going right (V0) -> wrong (V1, UPX) -> right (V1u, unpacked).

Two modes
  1) CSV mode (no GPU, no torch): read a Part B prediction file.
        python demo_B_flip.py Role_B_Outputs/predictions/preds_ResNet18_R2_1ch_seed42.csv
        python demo_B_flip.py <csv> --parent 3fa9 --manifest 01_Manifest/manifest_paired.csv
     CSV columns (written by 02_run_role_B_E0_E1.py): parent_id, y_true, pred_V0, pred_V1, pred_V1u
     (integer class ids; --manifest maps them to family names with load_and_audit_manifest).
  2) --live: run the real checkpoint on the three variants of one test parent.
        python demo_B_flip.py --live --manifest 01_Manifest/manifest_paired.csv \
            --data-root 02_Processed_Data --ckpt Role_B_Outputs/checkpoints/ResNet18_R2_1ch_seed42.pt
     Needs torch + torchvision and dataset_and_loader.py (Part B) in --code-dir (default: this folder).
     Without --parent it scans test parents and takes the first right -> wrong -> right one.

Model definitions are copied from 02_run_role_B_E0_E1.py. ResNet18 is built with weights=None:
the demo loads the trained state_dict, so no ImageNet download is needed.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import torch
    import torch.nn as nn
    import torchvision.models as tvm
except (ImportError, OSError):  # CSV mode still works without torch
    torch = None

NEED = {"parent_id", "y_true", "pred_V0", "pred_V1", "pred_V1u"}
VARIANTS = ["V0", "V1", "V1u"]
LABELS = [("V0  (original)", "pred_V0"), ("V1  (UPX packed)", "pred_V1"), ("V1u (unpacked)", "pred_V1u")]

if torch is not None:
    class CustomMalwareCNN(nn.Module):  # copied from 02_run_role_B_E0_E1.py
        def __init__(self, in_channels: int = 3, num_classes: int = 8):
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
                nn.AdaptiveAvgPool2d((1, 1))
            )
            self.classifier = nn.Linear(256, num_classes)

        def forward(self, x):
            return self.classifier(self.features(x).flatten(1))


def build_model(arch, num_classes):
    """Same architectures as Part B (ResNet18: weights come from the checkpoint)."""
    if arch == "ResNet18":
        m = tvm.resnet18(weights=None)
        m.fc = nn.Linear(m.fc.in_features, num_classes)
        return m
    if arch == "CustomCNN":
        return CustomMalwareCNN(3, num_classes)
    sys.exit(f"Unsupported --arch {arch} (use ResNet18 or CustomCNN)")


def load_model(arch, ckpt, num_classes):
    if torch is None:
        sys.exit("This mode needs torch and torchvision.")
    m = build_model(arch, num_classes)
    m.load_state_dict(torch.load(ckpt, map_location="cpu", weights_only=True))
    return m.eval()


def import_loader(code_dir):
    sys.path.insert(0, str(Path(code_dir).resolve()))
    try:
        from dataset_and_loader import load_and_audit_manifest, BODMASImageDataset
    except ImportError as e:
        sys.exit(f"Cannot import dataset_and_loader.py from {code_dir}: {e}")
    return load_and_audit_manifest, BODMASImageDataset


@torch.no_grad() if torch is not None else (lambda f: f)
def predict_one(model, tensor):
    """tensor (3,H,W) float32 -> (class id, probability)."""
    p = torch.softmax(model(tensor.unsqueeze(0)), dim=-1)[0]
    k = int(p.argmax())
    return k, float(p[k])


def run_csv(a):
    df = pd.read_csv(a.csv)
    miss = NEED - set(df.columns)
    if miss:
        sys.exit(f"Missing columns: {sorted(miss)}. Found: {list(df.columns)}")
    idx2fam = None
    if a.manifest:
        sys.path.insert(0, str(Path(a.code_dir).resolve()))
        try:
            from dataset_and_loader import load_and_audit_manifest
            _, _, idx2fam = load_and_audit_manifest(a.manifest, a.data_root or ".", drop_unknown=True)
        except Exception as e:  # keep the demo alive without the loader
            print(f"[!] could not map ids to family names: {e}", file=sys.stderr)
    name = (lambda k: idx2fam.get(int(k), k)) if idx2fam else (lambda k: k)

    ok0, ok1, oku = df.pred_V0 == df.y_true, df.pred_V1 == df.y_true, df.pred_V1u == df.y_true
    print(f"File: {a.csv}   parents: {len(df)}")
    print(f"Accuracy  V0 = {ok0.mean():.3f} | V1 (UPX) = {ok1.mean():.3f} | V1u (unpacked) = {oku.mean():.3f}")
    if ok0.sum():
        print(f"Of parents correct on V0, wrong on V1: {(ok0 & ~ok1).sum() / ok0.sum():.1%}")
    print()
    if a.parent:
        rows = df[df.parent_id.astype(str).str.startswith(a.parent)]
        if rows.empty:
            sys.exit("No parent matches that prefix.")
    else:
        rows = df[ok0 & ~ok1 & oku].head(1)
        if rows.empty:
            sys.exit("No parent that goes right -> wrong -> right in this file.")
    r = rows.iloc[0]
    print(f"parent_id  : {r.parent_id}\ntrue family: {name(r.y_true)}")
    for label, col in LABELS:
        print(f"  {label:<16} -> {name(r[col])!s:<12} [{'OK   ' if r[col] == r.y_true else 'WRONG'}]")


def run_live(a):
    if torch is None:
        sys.exit("--live needs torch and torchvision.")
    load_and_audit_manifest, BODMASImageDataset = import_loader(a.code_dir)
    df, fam2idx, idx2fam = load_and_audit_manifest(a.manifest, a.data_root, drop_unknown=True)
    model = load_model(a.arch, a.ckpt, len(fam2idx))

    def variant_rows(pid):
        return {v: df[(df.parent_id == pid) & (df.variant == v)] for v in VARIANTS}

    def run_parent(pid):
        out = {}
        for v, rows in variant_rows(pid).items():
            x, y, _, _ = BODMASImageDataset(rows, a.data_root, a.rep)[0]
            out[v] = (*predict_one(model, x), int(y))
        return out

    if a.parent:
        pids = sorted(p for p in df.parent_id.unique() if str(p).startswith(a.parent))
        if not pids:
            sys.exit("No parent matches that prefix.")
    else:
        pids = sorted(df[df.split == "test"].parent_id.unique())

    for n, pid in enumerate(pids):
        res = run_parent(pid)
        y = res["V0"][2]
        flip = res["V0"][0] == y and res["V1"][0] != y and res["V1u"][0] == y
        if a.parent or flip or n + 1 == len(pids):
            if not (a.parent or flip):
                print("[!] no right -> wrong -> right parent found; showing the last one scanned\n")
            break
    print(f"parent_id  : {pid}\ntrue family: {idx2fam[y]}\nmodel      : {a.arch} / {a.rep}  ({Path(a.ckpt).name})")
    for (label, _), v in zip(LABELS, VARIANTS):
        k, p, _ = res[v]
        print(f"  {label:<16} -> {idx2fam[k]:<12} p={p:.2f} [{'OK   ' if k == y else 'WRONG'}]")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?", help="prediction CSV (CSV mode)")
    ap.add_argument("--parent", default=None, help="parent_id prefix; default = auto-pick")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--code-dir", default=str(Path(__file__).resolve().parent),
                    help="folder with dataset_and_loader.py")
    ap.add_argument("--live", action="store_true", help="run the real checkpoint instead of reading a CSV")
    ap.add_argument("--ckpt", default="Role_B_Outputs/checkpoints/ResNet18_R2_1ch_seed42.pt")
    ap.add_argument("--arch", default="ResNet18", choices=["ResNet18", "CustomCNN"])
    ap.add_argument("--rep", default="R2_1ch", choices=["R1", "R2_1ch", "R2_3ch"])
    a = ap.parse_args()
    if a.live:
        if not (a.manifest and a.data_root):
            sys.exit("--live needs --manifest and --data-root")
        run_live(a)
    else:
        if not a.csv:
            sys.exit("Give a prediction CSV, or use --live.")
        run_csv(a)


if __name__ == "__main__":
    main()
