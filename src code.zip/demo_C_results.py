"""Demo C - Part C (analysis & defense): the E2 / E3 / E4 figures, plus a live E3 mask test.

Mode 1 (default): draw e2.png, e3.png, e4.png and print the tables.
    No data needed: the numbers are copied from the Final Report (Table 9, 10, 11),
    not recomputed. Say this if asked.
        python demo_C_results.py            # saves e2.png, e3.png, e4.png
        python demo_C_results.py --show     # also opens the windows

Mode 2 (--live-mask): the E3 idea on ONE parent with the real Part B checkpoint.
    Zero out each PE region of the packed (V1) file at full 512x512 and see whether the
    prediction changes (flip_occ), against zeroing a random contiguous segment of the same
    number of pixels inside the file content (flip_ctl), repeated --trials times.
    One parent only illustrates the method; the evidence is the 50-parent result in Table 10.
        python demo_C_results.py --live-mask --manifest 01_Manifest/manifest_paired.csv \
            --data-root 02_Processed_Data --ckpt Role_B_Outputs/checkpoints/ResNet18_R2_1ch_seed42.pt
    Needs torch + torchvision, and demo_B_flip.py + dataset_and_loader.py in the same folder
    (or --code-dir). Reads only derived files (R2 NPY, mask NPZ); no PE binary.
"""
import argparse
import sys
from pathlib import Path

import numpy as np

MASK_CODES = {  # from pe_images.py / dataset_and_loader.py
    "pad": 0, "header": 1, "code": 2, "stub": 3,
    "compressed": 4, "resource": 5, "overlay": 6, "data_other": 7,
}

# ---- Table 9 (E2): accuracy, mean over 9 runs ----
E2 = {
    "CNN": {"control": (0.962, 0.889), "biased": (0.358, 0.303)},
    "B1":  {"control": (0.980, 0.977), "biased": (0.296, 0.199)},
}  # (acc group A on V0, acc group B on V1)

# ---- Table 10 (E3): V1 region masking, flip_occ vs flip_ctl ----
E3 = [
    ("header",     0.040, 0.100),
    ("stub",       0.096, 0.111),
    ("compressed", 0.420, 0.380),
    ("resource",   0.325, 0.231),
    ("overlay",    0.382, 0.390),
]

# ---- Table 11 (E4): Macro-F1 ----
E4 = [  # name, F1 V0, F1 V1, F1 V1u
    ("P0 no defense",   0.993, 0.318, 0.993),
    ("P1 train V0+V1",  0.973, 0.976, 0.968),
    ("P2 mask entropy", 0.993, 0.226, 0.993),
]


# ------------------------------------------------------------------ mode 1
def grouped(ax, labels, series, names, ylabel, title, ylim=None):
    x = np.arange(len(labels))
    w = 0.8 / len(series)
    for i, (vals, n) in enumerate(zip(series, names)):
        bars = ax.bar(x + i * w - 0.4 + w / 2, vals, w, label=n)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.01, f"{v:.2f}", ha="center", fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    if ylim:
        ax.set_ylim(*ylim)
    ax.legend()


def run_figures(show):
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4))
    labels = ["CNN control", "CNN biased", "B1 control", "B1 biased"]
    accA = [E2["CNN"]["control"][0], E2["CNN"]["biased"][0], E2["B1"]["control"][0], E2["B1"]["biased"][0]]
    accB = [E2["CNN"]["control"][1], E2["CNN"]["biased"][1], E2["B1"]["control"][1], E2["B1"]["biased"][1]]
    grouped(ax, labels, [accA, accB], ["group A on V0", "group B on V1"], "accuracy",
            "E2: accuracy collapses when packing is uneven", (0, 1.1))
    plt.tight_layout(); plt.savefig("e2.png", dpi=150)

    fig, ax = plt.subplots(figsize=(7, 4))
    grouped(ax, [r[0] for r in E3], [[r[1] for r in E3], [r[2] for r in E3]],
            ["mask region (flip_occ)", "random same-size (flip_ctl)"], "flip rate",
            "E3 (V1): only 'resource' exceeds its control", (0, 0.5))
    plt.tight_layout(); plt.savefig("e3.png", dpi=150)

    fig, ax = plt.subplots(figsize=(7, 4))
    grouped(ax, [r[0] for r in E4], [[r[1] for r in E4], [r[2] for r in E4], [r[3] for r in E4]],
            ["V0 clean", "V1 UPX", "V1u unpacked"], "Macro-F1",
            "E4: train-on-packed (P1) helps, entropy masking (P2) does not", (0, 1.1))
    plt.tight_layout(); plt.savefig("e4.png", dpi=150)

    print("E2  acc group A on V0 / group B on V1")
    for m in E2:
        for s in E2[m]:
            print(f"  {m:<4} {s:<8} {E2[m][s][0]:.3f} / {E2[m][s][1]:.3f}")
    print("\nE3  V1 region   flip_occ  flip_ctl")
    for r in E3:
        print(f"  {r[0]:<11} {r[1]:.3f}     {r[2]:.3f}")
    print("\nE4  config            F1 V0   F1 V1   F1 V1u")
    for r in E4:
        print(f"  {r[0]:<18} {r[1]:.3f}   {r[2]:.3f}   {r[3]:.3f}")
    print("\nSaved e2.png, e3.png, e4.png")
    if show:
        plt.show()


# ------------------------------------------------------------------ mode 2
def region_tests(arr, mask, rng, trials=20):
    """arr, mask: (512, 512). Yield (region, n_pixels, occluded_arr, [control_arrs]).

    occluded  = every pixel of the region set to 0 (full resolution)
    control   = a random contiguous run (row-major offsets) of the same pixel count,
                inside the file content (mask != pad), set to 0.
    Pure numpy so it can be checked without torch.
    """
    flat_mask = mask.reshape(-1)
    content = int((flat_mask != MASK_CODES["pad"]).sum())
    for name, code in MASK_CODES.items():
        if name == "pad":
            continue
        sel = mask == code
        n = int(sel.sum())
        if n == 0:
            continue
        occ = arr.copy()
        occ[sel] = 0.0
        ctls = []
        if n <= content:
            for _ in range(trials):
                s = int(rng.integers(0, content - n + 1))
                c = arr.reshape(-1).copy()
                c[s:s + n] = 0.0
                ctls.append(c.reshape(arr.shape))
        yield name, n, occ, ctls


def run_live_mask(a):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        import demo_B_flip as B
    except ImportError as e:
        sys.exit(f"--live-mask needs demo_B_flip.py in the same folder: {e}")
    if B.torch is None:
        sys.exit("--live-mask needs torch and torchvision.")
    import torch

    load_and_audit_manifest, _ = B.import_loader(a.code_dir)
    df, fam2idx, idx2fam = load_and_audit_manifest(a.manifest, a.data_root, drop_unknown=True)
    model = B.load_model("ResNet18", a.ckpt, len(fam2idx))
    root = Path(a.data_root)

    def predict(arr):
        t = torch.from_numpy(np.stack([arr, arr, arr]).astype(np.float32))  # same as R2_1ch
        return B.predict_one(model, t)[0]

    if a.parent:
        pids = sorted(p for p in df.parent_id.unique() if str(p).startswith(a.parent))
        if not pids:
            sys.exit("No parent matches that prefix.")
    else:
        pids = sorted(df[df.split == "test"].parent_id.unique())
    pid = pids[0]
    row = df[(df.parent_id == pid) & (df.variant == "V1")].iloc[0]
    arr = np.load(root / row["image_path_r2"]).astype(np.float32) / 255.0
    mask = np.load(root / row["mask_path_r2"])["mask"]
    true = int(row["label_idx"])
    base = predict(arr)
    rng = np.random.default_rng(a.seed)

    print(f"parent_id: {pid}   true family: {idx2fam[true]}   (variant V1, UPX packed)")
    print(f"unmasked prediction: {idx2fam[base]} [{'OK' if base == true else 'WRONG'}]\n")
    print(f"{'region':<11} {'pixels':>7}  {'pred when masked':<16} {'changed':<8} control changed")
    for name, n, occ, ctls in region_tests(arr, mask, rng, a.trials):
        p = predict(occ)
        c = sum(predict(x) != base for x in ctls)
        ctl = f"{c}/{len(ctls)}" if ctls else "n/a"
        print(f"{name:<11} {n:>7}  {idx2fam[p]:<16} {'YES' if p != base else 'no':<8} {ctl}")
    print("\nA region counts as carrying its own signal only if masking it changes the prediction "
          "clearly more often than the control, over many parents (Table 10: only 'resource', 0.325 vs 0.231).")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--live-mask", action="store_true")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--ckpt", default="Role_B_Outputs/checkpoints/ResNet18_R2_1ch_seed42.pt")
    ap.add_argument("--parent", default=None)
    ap.add_argument("--trials", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--code-dir", default=str(Path(__file__).resolve().parent))
    a = ap.parse_args()
    if a.live_mask:
        if not (a.manifest and a.data_root):
            sys.exit("--live-mask needs --manifest and --data-root")
        run_live_mask(a)
    else:
        run_figures(a.show)


if __name__ == "__main__":
    main()
