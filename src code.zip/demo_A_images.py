"""Demo A - show one parent as V0 / V1 (UPX) / V1u (unpacked): R1 image, R2 with PE-region
mask, and the 512-byte-window entropy profile.

Uses the real Part A delivery layout (written by pe_images.py, read by Part B's loader):
  manifest_paired.csv columns : sample_id, parent_id, variant, family, split,
                                image_path_r1, image_path_r2, mask_path_r2
  paths are relative to --data-root; entropy is <data-root>/entropy/<sample_id>.npz
  (arrays win256 / win512, NaN where the window has no bytes); mask NPZ key = "mask".
MASK_CODES is copied from pe_images.py / dataset_and_loader.py.

Usage:
    python demo_A_images.py --manifest 01_Manifest/manifest_paired.csv --data-root 02_Processed_Data
    python demo_A_images.py --manifest ... --data-root ... --parent 3fa9
    python demo_A_images.py --manifest ... --data-root ... --pred preds_ResNet18_R2_1ch_seed42.csv
        (--pred = Part B prediction CSV: picks a parent that goes right -> wrong -> right,
         so A, B and C can demo the SAME parent)
    add --save demo_A.png to write a file instead of opening a window.
Only derived files are read; no PE binary is touched.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

MASK_CODES = {  # from pe_images.py
    "pad": 0, "header": 1, "code": 2, "stub": 3,
    "compressed": 4, "resource": 5, "overlay": 6, "data_other": 7,
}
VARIANTS = ["V0", "V1", "V1u"]
TITLES = {"V0": "V0 - original", "V1": "V1 - UPX packed", "V1u": "V1u - unpacked"}
NEED = {"sample_id", "parent_id", "variant", "image_path_r1", "image_path_r2", "mask_path_r2"}


def load_manifest(path):
    df = pd.read_csv(path)
    miss = NEED - set(df.columns)
    if miss:
        sys.exit(f"Manifest lacks columns {sorted(miss)}. Found: {list(df.columns)}")
    return df


def pick_parent(df, parent=None, pred_csv=None):
    complete = df.groupby("parent_id")["variant"].apply(lambda s: set(s) >= set(VARIANTS))
    ok = set(complete[complete].index)
    if parent:
        hits = sorted(p for p in ok if str(p).startswith(parent))
        if not hits:
            sys.exit("No parent with V0, V1 and V1u matches that prefix.")
        return hits[0]
    if pred_csv:
        p = pd.read_csv(pred_csv)
        flip = p[(p.pred_V0 == p.y_true) & (p.pred_V1 != p.y_true) & (p.pred_V1u == p.y_true)]
        flip = [x for x in flip.parent_id if x in ok]
        if flip:
            return flip[0]
        print("[!] no right->wrong->right parent in that CSV; falling back to first test parent", file=sys.stderr)
    if "split" in df.columns:
        test = sorted(p for p in ok if (df[df.parent_id == p]["split"] == "test").any())
        if test:
            return test[0]
    return sorted(ok)[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--parent", default=None, help="parent_id or prefix")
    ap.add_argument("--pred", default=None, help="Part B prediction CSV (to pick a flip parent)")
    ap.add_argument("--save", default=None)
    a = ap.parse_args()

    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    from PIL import Image

    root = Path(a.data_root)
    df = load_manifest(a.manifest)
    pid = pick_parent(df, a.parent, a.pred)
    fam = df[df.parent_id == pid]["family"].iloc[0] if "family" in df.columns else "?"
    print(f"parent: {pid}\nfamily: {fam}")

    cmap = ListedColormap(["#444444", "#1f77b4", "#2ca02c", "#9467bd",
                           "#d62728", "#ff7f0e", "#8c564b", "#bcbd22"])
    fig, axes = plt.subplots(3, 3, figsize=(12, 11))
    for j, v in enumerate(VARIANTS):
        r = df[(df.parent_id == pid) & (df.variant == v)].iloc[0]
        sid = r["sample_id"]
        r1 = Image.open(root / r["image_path_r1"]).convert("L")
        r2 = np.load(root / r["image_path_r2"])
        mask = np.load(root / r["mask_path_r2"])["mask"]
        ent = np.load(root / "entropy" / f"{sid}.npz")["win512"]  # NaN -> not plotted

        axes[0, j].imshow(r1, cmap="gray")
        axes[0, j].set_title(f"{TITLES[v]}\nR1 224x224")
        axes[1, j].imshow(r2, cmap="gray")
        axes[1, j].imshow(mask, cmap=cmap, vmin=0, vmax=7, alpha=0.45, interpolation="nearest")
        axes[1, j].set_title("R2 512x512 + PE-region mask")
        axes[2, j].plot(ent, lw=0.8)
        axes[2, j].axhline(7.2, color="r", ls="--", lw=0.8)  # descriptive reference only
        axes[2, j].set_ylim(0, 8)
        axes[2, j].set_xlabel("row (512-byte window)")
        axes[2, j].set_ylabel("entropy (bits/byte)")
        axes[2, j].set_title(f"mean = {np.nanmean(ent):.2f}")
        for i in (0, 1):
            axes[i, j].axis("off")

    handles = [plt.Rectangle((0, 0), 1, 1, color=cmap(c)) for c in range(8)]
    fig.legend(handles, list(MASK_CODES), ncol=8, loc="lower center", fontsize=8)
    fig.suptitle(f"parent {str(pid)[:12]}  ({fam})", fontsize=12)
    plt.tight_layout(rect=(0, 0.03, 1, 0.97))
    if a.save:
        plt.savefig(a.save, dpi=150)
        print("saved", a.save)
    else:
        plt.show()


if __name__ == "__main__":
    main()
