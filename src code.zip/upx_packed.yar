rule UPX_Packed_PE
{
    meta:
        description = "PE file that looks UPX-packed (section names / UPX marker)"
        author      = "Group 5 - IAM302T"
        note        = "Detection only. Stripped or modified UPX can evade it; confirm with Detect It Easy."

    strings:
        $sec0 = "UPX0" ascii
        $sec1 = "UPX1" ascii
        $mark = "UPX!" ascii

    condition:
        uint16(0) == 0x5A4D and
        ( ($sec0 and $sec1) or $mark )
}
